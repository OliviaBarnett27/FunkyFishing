﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data.Odbc;
using System.Security;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Collections;
using System.Security.Policy;
using System.Runtime.Remoting.Messaging;
using System.Xml.Linq;
using System.IO.Ports;
using System.Reflection;

namespace NEA1
{
    class Program
    {
        static void Main(string[] args)
        {
            //database connection
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=""C:\Documents\NewFunkyFishingDatabase.accdb"";Jet OLEDB:Database Password=1");
            connection.Open();
            Console.WriteLine();

            int[] thisLevelZoneFish = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }; //array used to hold the gish in all the zones in Free Fishing

            //menus

            string user = LogIn(); //logs in the user and stores their name in a variable

            double money = GetMoney(user); //gets the total amount of money that the logged-in user currently has

            int fishCount = GetFishCount(user); //gets the total number of fish the logged-in user has caught

            int mainMenuOption = 0;             //holds user's response to being prompted to choose an option from the main menu
            int locationMenuOption = 0;
            while (mainMenuOption != 9)         //while the option is not "exit", keep going forever
            {
                DisplayTitle(); //decoartive

                DisplayMenu(); //dispalys the main menu
                mainMenuOption = GetMainMenuChoice(); //MenuOption becomes the user's choice

                //FREE FISHING
                if (mainMenuOption == 1) //free fishing
                {
                    //welcome message + instructions
                    Console.WriteLine("Welcome to Free Fishing!");
                    Console.WriteLine("In this mode, you can catch as many fish as you want, in any of the available locations.");
                    Console.WriteLine("New locations will become available once enough fish have been caught.");
                    Console.WriteLine("Try to catch the biggest fish for each species and set a new record!");
                    Console.WriteLine();

                    DisplayLocationMenu(user); //displays the locations that are available to the currently logged-in user

                    locationMenuOption = GetLocationMenuChoice(); //user's choice of location

                    string locationName = "";

                    while (locationMenuOption != 9) //while the user does not want to exit
                    {
                        int numberOfZones = locationMenuOption + 3;

                        Random randomNumber = new Random(); //random number

                        //databse command
                        OleDbCommand getLocationName = new OleDbCommand();
                        getLocationName.Connection = connection;
                        getLocationName.CommandText = "SELECT * FROM Location WHERE [ID] = " + (locationMenuOption + 1); //select information from the record that contains the user's choice of location (+1 because the ID in the Locations table starts at 2)
                        OleDbDataReader reader2 = getLocationName.ExecuteReader();
                        while (reader2.Read())
                        {
                            locationName = reader2["LocationName"].ToString(); //holds the name of the chosen location
                        }

                        DisplayBoard(ref locationMenuOption, ref numberOfZones, ref locationName); //displays the board for the chosen location

                        locationMenuOption = PlayFreeFishing(locationMenuOption, numberOfZones, thisLevelZoneFish, user, connection); //will return 1 if the user wants to keep playing, 9 if they want to exit

                        money = GetMoney(user); //gets the total amount of money the user currently has
                    }
                }
                //SPEED FISHING
                else if (mainMenuOption == 2) //speed fishing
                {
                    Queue SpeedFishingQueue = new Queue(); //creates the queue that will hold all the fish for the round of speed fishing

                    //instructions
                    Console.WriteLine("Welcome to Speed Fishing!\n\nIn this mode, you will need to try to catch all the fish, one after the other, as quickly as possible.");
                    Console.WriteLine("Each level of increasing difficulty will have a higher amount of fish to catch.");
                    Console.WriteLine("You will gain points based on how any fish you catch, the rarity of the fish that you catch, and the time taken to complete the level");
                    Console.WriteLine("\nNote: The fish caught in this mode do not count to your total fish count or species-specific records");
                    Console.WriteLine();

                    DisplayLocationMenu(user); //displays all the locations that are available to the user
                    locationMenuOption = GetLocationMenuChoice(); //holds the user's choice of location

                    SpeedFishingQueue = SpeedFishingEnqueue(SpeedFishingQueue, locationMenuOption); //adds fish to the queue

                    int queueLength = SpeedFishingQueue.Count; //finds the length of the queue

                    PlaySpeedFishing(SpeedFishingQueue, queueLength, locationMenuOption, connection, user); //plays the round of speed fishing

                }
                //RECORD BOOK
                else if (mainMenuOption == 3) //record book
                {
                    RecordBook(user); //shows the record book for the logged-in user
                }
            }
            //exit message
            Console.WriteLine("Thank you for playing! See you next time!");
            Console.ReadLine();
        }

        //PLAY SPEED FISHING
        private static void PlaySpeedFishing(Queue SpeedFishingQueue, int queueLength, int locationMenuOption, OleDbConnection connection, string user)
        {
            //SpeedFishingQueue is the queue that holds the fish for the round
            //queueLength is the length of SpeedFishingQueue
            //locationMenuOption is the value of the location in which the round is taking place
            //connection is the database connection
            //user is the logged-in user's name

            DateTime startTime = DateTime.Now; //gets the current date and time

            //variables
            int rarity = 0;
            string species = "";
            int speedFishingFishCount = 0;
            int rarityPoints = 0;

            for (int i = 1; i <= queueLength; i++) //until it has reached the end of the queue
            {
                species = Convert.ToString(SpeedFishingQueue.Dequeue()); //dequeues a fish from the queue and holds it in a variable

                Console.WriteLine();

                //database command
                OleDbCommand findFishByQueue = new OleDbCommand();
                findFishByQueue.Connection = connection;
                findFishByQueue.CommandText = "SELECT * FROM FishTable WHERE [Species] = '" + species + "'"; //selects from the record the contains the species of the fish that has been dequeued
                OleDbDataReader reader = findFishByQueue.ExecuteReader();
                while (reader.Read())
                {
                    rarity = Convert.ToInt32(reader["Rarity"].ToString()); //hold the rarity of the fish that has been dequeued in a variable
                }

                string generatedArrowSequence = GenerateArrowSequence(rarity, locationMenuOption); //generates the sequence that the user must re-enter based on the rarity of the fish that has been dequeued and the value of the loacation in which the round is taking place
                Console.WriteLine("Sequence " + i + ":");
                Console.WriteLine(generatedArrowSequence); //prints the sequence to the console

                Console.WriteLine();
                Console.WriteLine("Please enter the sequence:"); //prompts the user to re-enter the sequnece

                string userArrowSequence = Console.ReadLine(); //stores the user's sequence in a variable

                Console.WriteLine();

                bool correctArrowSequence = ValidateArrowSequence(generatedArrowSequence, userArrowSequence); //checks if the user's sequence matches the generated sequence

                if (correctArrowSequence) //if the sequences match
                {
                    Console.WriteLine("Fish caught!");
                    Console.WriteLine("Fish " + i + ": " + species); //writes the species of the fish that has been caught to the console
                    speedFishingFishCount++; //the number of fish caught in this round increases by 1
                    rarityPoints += (rarity * 2); //calculates the rarity points accquired for the fish that has been caught and adds it to the total
                }
                else //if the sequences don't match
                {
                    Console.WriteLine("Fish missed!");
                }
            }

            double seconds = CalculateTime(startTime); //calculates the time taken by the user to complete the round

            Console.WriteLine();
            Console.WriteLine("FINISH!\nLevel completed in " + seconds + " seconds"); //writes the number of seconds taken to complete the level to the console
            Console.WriteLine();

            int points = CalculatePoints(locationMenuOption, queueLength, speedFishingFishCount, rarityPoints, seconds); //calculate the points that the user earned in this round
            Console.WriteLine("Your points for this level: " + points); //writes the points that the user earned in this round to the console

            CheckSpeedFishingRecords(points, locationMenuOption, connection, user); //checks if the user's points are higher than the points stored in the database

            SpeedFishingQueue.Clear(); //empties the queue
        }

        //CHECK SPEED FISHING RECORDS (SPEED FISHING)
        //checks the points that have just been earned against the points that are currently stored in the database
        //used to call AddNewSpeedFishingRecord if the points that have just been earned are higher than the record
        private static void CheckSpeedFishingRecords(int points, int locationMenuOption, OleDbConnection connection, string user)
        {
            //points is the points that have just been earned
            //locationMenuOption is the value of the location in which the round has taken place
            //connection is the database connectiom
            //user is the logged-in user's name

            int record = 0; //will hold the points currently stored in the database

            //database command
            OleDbCommand checkRecords = new OleDbCommand();
            checkRecords.Connection = connection;
            checkRecords.CommandText = "SELECT * FROM SpeedFishingRecords WHERE ID = " + locationMenuOption; //select from the record that contains the value of the location in which the round has taken place
            OleDbDataReader reader1 = checkRecords.ExecuteReader();
            while (reader1.Read())
            {
                record = Convert.ToInt32(reader1["Points"].ToString()); //holds the points currently stored in the database in a variable
            }
            if (record < points) //if the points currently stored in the database are lower than the points that have just been earned...
            {
                AddNewSpeedFishingRecord(points, user, record, locationMenuOption, connection); //...add the points that have just been earned to the database
            }
        }

        //ADD NEW SPEED FISHING RECORD (SPEED FISHING)
        //called from CheckSpeedFishingRecords() if the points that have just been earned are higher than the points stored in the database
        //updates the record for the current location to the points that have just been earned
        private static void AddNewSpeedFishingRecord(int points, string user, int record, int locationMenuOption, OleDbConnection connection)
        {
            //points is the points that have just been earned
            //user is the logged-in user's anme
            //record is the points that are currently stored in the database
            //locationMenuOption is the value of the location in which the round has taken place
            //connection is the database connection

            Console.WriteLine("RECORD BROKEN!");
            Console.WriteLine("Previous record: " + record + " points\nNew record: " + points + " points"); //prints the old record and the new record

            string dateAndTime = Convert.ToString(DateTime.Now); //gets the current date and time
            Console.WriteLine("Record set on " + dateAndTime);

            //database command
            OleDbCommand newRecord = new OleDbCommand();
            newRecord.Connection = connection;
            newRecord.CommandText = "UPDATE SpeedFishingRecords SET Points = " + points + ", UserID = '" + user + "', [DateTime] = '" + dateAndTime + "' WHERE ID = " + locationMenuOption; //replaces the previously stored points with the points that have just been earned and other details
            newRecord.ExecuteNonQuery();
        }

        //CALCULATE TIME (SPEED FISHING)
        //calculates the amount of time taken for the user to complete the round of speed fishing
        private static double CalculateTime(DateTime startTime)
        {
            //startTime is the time at which the round of speed fishing began

            DateTime endTime = DateTime.Now; //the time at which the round of speed fishing ended

            long elapsedTicks = endTime.Ticks - startTime.Ticks; //subtracts the end time from the start time to give the amount of time that passed as the round was being completed
            TimeSpan elapsedSpan = new TimeSpan(elapsedTicks); //time span

            double seconds = Convert.ToDouble(elapsedSpan.TotalSeconds); //converts the time span to seconds and stores it in a variable
            return seconds;
        }

        //CHOOSE RANDOM FISH (FREE FISHING)
        //chooses random fish IDs that will be in the different zones in the location
        //based on random numbers
        private static void ChooseRandomFish(int locationMenuOption, int[] thisLevelZoneFish, OleDbConnection connection)
        {
            //locationMenuOption is the value of the location in which the round is taking place
            //thisLevelZoneFish is the array that will hold the fish for every zone
            //connection is the database connection

            Random randomNumber = new Random(); //random number

            //random variables
            int randomFish = 0;

            //variables
            int currentFishID = 0;

            for (int i = 0; i <= locationMenuOption + 3; i++)
            {
                randomFish = randomNumber.Next(1, 7); //picks random number between 1 and 6 (6 fish species per location)

                //makes fish with higher values appear less frequently
                if (randomFish >= 4) //if randomFish = 4, 5 or 6...
                {
                    int keepRareFish = randomNumber.Next(1, 4); //...pick a random number between 1 and 3
                    if (keepRareFish != 1) //if keepRareFish is not 1...
                    {
                        randomFish = randomNumber.Next(1, 5); //...a new (smaller) random number is picked between 1 and 4, which is what will instead be stored in randomFish
                    }
                }

                //database command
                OleDbCommand findFishByrandomFish = new OleDbCommand();
                findFishByrandomFish.Connection = connection;
                findFishByrandomFish.CommandText = "SELECT * FROM FishTable WHERE [ID] = " + (randomFish + (6 * (locationMenuOption - 1))); //select the fish which has the ID that corresponds to randomFish (calculation ensures correct location)
                OleDbDataReader reader = findFishByrandomFish.ExecuteReader();

                while (reader.Read())
                {
                    currentFishID = Convert.ToInt32(reader["ID"].ToString()); //holds the ID of the fish that was randomly selected
                }

                AddToArray(thisLevelZoneFish, i, currentFishID); //will add the randomly selected fish ID to the array
            }
            return;
        }

        //FIND RARITY (FREE FISHING)
        //finds the rarity of the fish in the zone that the user has selected
        //used to generate the arrow sequence
        private static int FindRarity(int[] thisLevelZoneFish, int fishingZone, OleDbConnection connection)
        {
            //thisLevelZoneFish is the array that holds the fish for all the zones
            //fishingZone is the value of the zone that the user has selected
            //connection is the database connection

            int rarity = 0;

            int currentZoneFish = thisLevelZoneFish[fishingZone]; //takes the ID of the fish that is in the zone that the user chose from the array and stores it in a variable

            //database command
            OleDbCommand findFishRarity = new OleDbCommand();
            findFishRarity.Connection = connection;
            findFishRarity.CommandText = "SELECT * FROM FishTable WHERE ID = " + currentZoneFish; //select the fish with the ID that corresponds to currentZoneFish
            OleDbDataReader reader = findFishRarity.ExecuteReader();
            while (reader.Read())
            {
                rarity = Convert.ToInt32(reader["Rarity"].ToString()); //store the fish's rarity in a variable
            }
            return rarity;
        }

        //CALCULATE CURRENT FISH WEIGHT (FREE FISHING)
        //calculates the weight of the fish that the user has caught based on its average weight
        private static double CalculateCurrentFishWeight(double currentFishAverageWeight)
        {
            Random randomNumber = new Random();

            double currentFishWeight = currentFishAverageWeight;

            double weightFactor = randomNumber.Next(0, 16);

            int addOrSubtract = randomNumber.Next(0, 2);

            weightFactor = (currentFishWeight / 100) * weightFactor;

            if (addOrSubtract == 1)
            {
                currentFishWeight -= weightFactor;

                if (currentFishWeight < 0)
                {
                    currentFishWeight = currentFishAverageWeight;
                }
            }
            else
            {
                currentFishWeight += weightFactor;
            }

            currentFishWeight = Math.Round(currentFishWeight, 3);

            return currentFishWeight;
        }

        //CALCULATE CURRENT FISH PRICE (FREE FISHING)
        //calculates the price of the fish that has been caught, based on its average price, average weight and calculated weight
        private static double CalculateCurrentFishPrice(double currentFishAveragePrice, double currentFishWeight, double currentFishAverageWeight)
        {
            //currentFishAveragePrice is the average price of the fish that the user has caught
            //currentFishWeight is the calculated weight of the fish that the user has caught
            //currentFishAverageWeight is the average weight of the fish that the user has caught

            double currentFishPrice = (currentFishAveragePrice + ((currentFishWeight - currentFishAverageWeight) * (currentFishAveragePrice / (currentFishAveragePrice / 3)))); //execute the formula and store it in a variable

            currentFishPrice = Math.Round(currentFishPrice, 2); //round the price to two decimal places

            return currentFishPrice;
        }

        //ADD TO FISH COUNT (FREE FISHING)
        //when a fish has been caught, it adds the species to the user's total fish count
        private static void AddToFishCount(string user, string currentFishSpecies, OleDbConnection connection)
        {
            //user is the logged-in user's name
            //currentFishSpecies is the species of the fish that the user has just caught
            //connection is the database connection

            //database command
            OleDbCommand addToFishCount = new OleDbCommand();
            addToFishCount.Connection = connection;
            addToFishCount.CommandText = "INSERT INTO [FishCount] ([" + user + "]) VALUES ('" + currentFishSpecies + "')"; //insert the species of the fish into the field in the FishCount table that has the same name as user
            addToFishCount.ExecuteNonQuery();
        }

        //CHECK FISH RECORDS (FREE FISHING)
        //takes the current record for the species that has just been caught and compares it to the weight of the fish that has just been caught
        //used to call AddNewFishRecord()
        private static void CheckFishRecords(string user, string currentFishSpecies, int locationMenuOption, double currentFishWeight, OleDbConnection connection)
        {
            //user is the logged-in user's name
            //currentFishSpecies is the species of the fish that has just been caught
            //locationMenuOption is the value of the location in which the round is taking place
            //currentFishWeight is the weight of the fish that has just been caught
            //connection is the database connection

            double record = 0; //will hold the record that is currently stored in the database

            //database command
            OleDbCommand checkRecords = new OleDbCommand();
            checkRecords.Connection = connection;
            checkRecords.CommandText = "SELECT * FROM Records WHERE FishID = '" + currentFishSpecies + "' AND LocationID = " + (locationMenuOption + 1); //selects from the record that matches the fish that was just caught
            OleDbDataReader reader3 = checkRecords.ExecuteReader();
            while (reader3.Read())
            {
                record = Convert.ToDouble(reader3["Weight"].ToString()); //holds the weight of the current record in the variable
            }
            if (record < currentFishWeight) //if the currently stored record weight is lower than the fish that was just caught
            {
                AddNewFishRecord(user, record, currentFishWeight, currentFishSpecies, connection); //add the fish that was just caught to the record table
            }
        }

        //ADD NEW FISH RECORD (FREE FISHING)
        //called from CheckFishRecords() if the fish that has just been caught is bigger than the fish currently held in the FishRecords table
        //replaces the old record with the fish that has just been caught
        private static void AddNewFishRecord(string user, double record, double currentFishWeight, string currentFishSpecies, OleDbConnection connection)
        {
            //user is the logged-in user's name
            //record is the previously stored record
            //currentFishWeight is the weight of the fish that has just been caught
            //currentFishSpecies is the species of the fish that has just been caught
            //connection is the database connection

            Console.WriteLine("RECORD BROKEN!");
            Console.WriteLine("Previous record: " + record + "kg\nNew record: " + currentFishWeight + "kg"); //writes out the old record and the new record
            string dateAndTime = Convert.ToString(DateTime.Now); //gets the current date and time
            Console.WriteLine("Record set at " + dateAndTime);

            //database command
            OleDbCommand newRecord = new OleDbCommand();
            newRecord.Connection = connection;
            newRecord.CommandText = "UPDATE Records SET Weight = " + currentFishWeight + ", UserID = '" + user + "', [Date/Time] = '" + dateAndTime + "' WHERE FishID = '" + currentFishSpecies + "'"; //updates the record that holds the required species to hold the information about the fish that was just caught
            newRecord.ExecuteNonQuery();
        }

        //DISPLAY MAIN MENU
        //shows the main menu to the user so that they can choose what they would like to do
        //welcomes the user to the game
        private static void DisplayMenu()
        {
            Console.WriteLine("Welcome to Funky Fishing! What would you like to do?\n\n1) Free Fishing\n2) Speed Fishing\n3) View Records\n\n9) Exit");
        }

        //GET MAIN MENU CHOICE
        //takes the user's response after DisplayMenu()
        private static int GetMainMenuChoice()
        {
            int Choice = 0;
            Console.Write("Please enter your choice: ");
            Choice = Convert.ToInt32(Console.ReadLine()); //converts user input to an integer
            Console.WriteLine();
            return Choice;
        }

        //DISPLAY LOCATION MENU (FREE FISHING + SPEED FISHING)
        //displays the available locations from which the user can choose
        private static void DisplayLocationMenu(string user)
        {
            //user is the logged-in user's name

            int numberOfLevels = 1; //will store how many levels the user has unlocked (1 is the default value)
            string levelName = ""; //will store the name of an unlocked location
            int counter = 1; //used to display all the unlocked locations

            Console.WriteLine("Please choose a location:");

            //database connection
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=""C:\Documents\NewFunkyFishingDatabase.accdb"";Jet OLEDB:Database Password=1");
            connection.Open();

            //database command
            OleDbCommand getLevelsUnlocked = new OleDbCommand();
            getLevelsUnlocked.Connection = connection;
            getLevelsUnlocked.CommandText = "SELECT * FROM Users WHERE [Username] = '" + user + "'"; //select from the record that contains user within the Users table
            OleDbDataReader reader = getLevelsUnlocked.ExecuteReader();

            while (reader.Read())
            {
                numberOfLevels = Convert.ToInt32(reader["LevelsUnlocked"].ToString()); //reads how many levels the user has unlocked from the database
            }

            //database command
            OleDbCommand getLevelNames = new OleDbCommand();
            getLevelNames.Connection = connection;
            getLevelNames.CommandText = "SELECT * FROM Location WHERE [ID] <= " + (numberOfLevels + 1); //selects all the locations up to the number that the user has unlocked + 1 (LocationID starts at 2)
            OleDbDataReader reader2 = getLevelNames.ExecuteReader();

            while (reader2.Read())
            {
                levelName = reader2["LocationName"].ToString();
                Console.WriteLine(counter + ") " + levelName); //print the number of the location and its name
                counter++; //counter increment by 1
            }
            Console.WriteLine();
        }

        //GET LOCATION MENU CHOICE (FREE FISHING + SPEED FISHING)
        //takes the user's response after DisplayLocationMenu()
        private static int GetLocationMenuChoice()
        {
            int Choice = 0; //will hold user's response
            Console.WriteLine("Please enter your choice:");
            Choice = Convert.ToInt32(Console.ReadLine()); //converts user input to an integer
            Console.WriteLine();
            return Choice;
        }

        //DISPLAY BOARD (FREE FISHING)
        private static void DisplayBoard(ref int locationValue, ref int numberOfZones, ref string locationName)
        {
            //locationValue is the numeric value of the current location - used to display difficulty
            //numberOfZones is the number of zones for the current location - they will be printed to the console
            //locationName is the name of the current location - it will be printed to the console

            DateTime dateAndTime = DateTime.Now; //gets the current date and time

            Console.WriteLine("LEVEL: " + locationName.ToUpper()); //writes the name of the current location to the console
            Console.WriteLine("          _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _");
            Console.WriteLine("         |                                                         |");
            Console.WriteLine("         |  Difficulty                        " + dateAndTime + "  |");
            Console.WriteLine("         |      " + locationValue + "                                                  |");
            Console.WriteLine("         |                         ZONES                           |");
            for (int i = 1; i <= numberOfZones; i++)    //prints zones with number values until the required amount have been printed
            {
                if (i < 10)
                {
                    Console.WriteLine("         |                           " + (i) + "                             |");
                }
                else
                {
                    Console.WriteLine("         |                           " + (i) + "                            |"); //fixing formatting
                }
            }
            Console.WriteLine("         |                                                         |");
            Console.WriteLine("         |                          CAST                    Exit   |");
            Console.WriteLine("         |_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _|");
            Console.WriteLine("");
            return;
        }

        //PLAY FREE FISHING

        private static int PlayFreeFishing(int locationMenuOption, int numberOfZones, int[] thisLevelZoneFish, string user, OleDbConnection connection)
        {
            //locationMenuOption is the value of the location in which the round is taking place
            //numberOfZones is the number of zones for the current location in which the round is taking place
            //thisLevelZoneFish is the array that holds the IDs of the fish for the zones in this round
            //user is the logged-in user's name
            //connetion is the connection to the database

            double money = GetMoney(user); //holds the total amount of money the user currently has

            //variables
            string currentFishSpecies = "";
            double currentFishAverageWeight = 0;
            int currentFishRarity = 0;
            double currentFishAveragePrice = 0;

            ChooseRandomFish(locationMenuOption, thisLevelZoneFish, connection); //puts fish in each zone

            int fishingZone = 0;

            Console.WriteLine("What would you like to do?"); //asks the user what they want to do
            Console.WriteLine("\n1) Cast!\n9) Exit");
            int optionchoice = Convert.ToInt32(Console.ReadLine()); //holds the user's choice

            //LOOPS BACK HERE EACH TIME A FISH IS CAUGHT UNTIL THE USER WANTS TO EXIT
            if (optionchoice == 1) //1) Cast
            {
                money = GetMoney(user); //holds the total amount of money the user currently has
                Console.WriteLine("Would you like to activate the Show Fish powerup for £3000? (Y/N)"); //asks if the user wants to use Show Fish
                Console.WriteLine("You currently have: £" + money);

                string useShowFishPowerup = Console.ReadLine(); //holds the user's response

                Console.WriteLine();

                if (useShowFishPowerup == "Y" && money >= 3000) //if the user wants to use the powerup and they have enough money
                {
                    Console.WriteLine("Thank you for purchasing Show Fish!");
                    money -= 3000; //subtract 3000 from their money total for the cost of the powerup
                    Console.WriteLine("You now have £" + money); //display the new money total
                    UpdateMoney(money, user); //update the user's money total in the database
                    RevealFish(numberOfZones, thisLevelZoneFish); //reveals which fish is in each zone
                }

                Console.WriteLine("Choose a fishing zone!"); //asks the user which zone they want to fish in
                fishingZone = (Convert.ToInt32(Console.ReadLine()) - 1); //holds the user's response (-1 to match with array (arrays start at 0))

                int rarity = FindRarity(thisLevelZoneFish, fishingZone, connection); //will hold the rarity of the fish stored in the current zone (pulled from database)

                string arrowSequence = GenerateArrowSequence(locationMenuOption, rarity); //stores the arrow sequence that is generated based on the fish and the location for the user to re-enter

                //database command
                OleDbCommand findFishInChosenZone = new OleDbCommand();
                findFishInChosenZone.Connection = connection;
                findFishInChosenZone.CommandText = "SELECT * FROM FishTable WHERE Rarity = " + rarity + " AND LocationID = " + (locationMenuOption + 1); //takes the details from the record that contains the rarity of the fish in the chosen zone and the value of the location in which the round is taking place
                OleDbDataReader reader5 = findFishInChosenZone.ExecuteReader();
                while (reader5.Read())
                {
                    currentFishSpecies = reader5["Species"].ToString();  //holds the species of the fish
                    currentFishAverageWeight = Convert.ToDouble(reader5["Average Weight"].ToString()); //holds the average weight of the fish
                    currentFishRarity = Convert.ToInt32(reader5["Rarity"].ToString()); //holds the rarity of the fish
                    currentFishAveragePrice = Convert.ToDouble(reader5["Average Selling Price"].ToString()); //holds the average price of the fish
                }

                double currentFishWeight = CalculateCurrentFishWeight(currentFishAverageWeight); //calculates the weight of the fish in the chosen zone based on the average weight

                double currentFishPrice = CalculateCurrentFishPrice(currentFishAveragePrice, currentFishWeight, currentFishAverageWeight); //calculates the price of the fish in the chosen zone based on average price, weight and average weight

                Console.WriteLine(arrowSequence); //displays the generated arrow sequence on the console
                Console.WriteLine("\nPlease enter the sequence:"); //prompts the user to re-enter the sequence

                string userInputArrowSequence = Console.ReadLine(); //holds the user's sequence

                bool arrowSequenceCorrect = ValidateArrowSequence(arrowSequence, userInputArrowSequence); //checks if the user's input matches the generated sequence

                //fish caught or missed
                if (arrowSequenceCorrect) //fish caught
                {
                    Console.WriteLine("\nFish Caught!");

                    //writes information about the fish that has been caught to the console
                    Console.WriteLine(currentFishSpecies);
                    Console.WriteLine("Rarity: " + currentFishRarity);
                    Console.WriteLine("Weight: " + currentFishWeight + "kg");
                    Console.WriteLine("Price: £" + currentFishPrice);

                    money += currentFishPrice; //add the price of the fish to the user's money total

                    AddToFishCount(user, currentFishSpecies, connection); //adds the fish that has just been caught to the user's total fish count

                    CheckFishRecords(user, currentFishSpecies, locationMenuOption, currentFishWeight, connection); //checks to see if the weight of the fish that has just been caught is bigger than the record
                }
                else //fish missed
                {
                    Console.WriteLine("Fish missed!");
                }

                Console.WriteLine();
                int fishCount = GetFishCount(user); //holds the total number of fish that the user has caught
                string status = ""; //will hold the status of the user

                if (fishCount == 50 || fishCount == 100 || fishCount == 200 || fishCount == 500 || fishCount == 1000 || fishCount == 10000 || fishCount == 1000000) //if the user has caught a ceratin number of fish
                {
                    status = GetStatus(user, fishCount); //gets the current status of the user, which will have updated
                    Console.WriteLine("You have caught " + fishCount + " fish! Your status is now " + status); //displays how many fish have been caught and the user's status
                    Console.WriteLine("New level unlocked!");
                }

                UpdateMoney(money, user); //updates the total amount of money that the user currently has to the database
                Console.WriteLine("");
                return 1; //loops back to asking if the user would like to Cast or Exit
            }
            else if (optionchoice == 9) //if the user wants to exit
            {
                Console.WriteLine("\nThank you for playing Free Fishing!\nPress enter to return to the Main Menu");
                Console.ReadLine();
                return 9; //returns the value that will exit the loop
            }
            return 1;
        }

        //ADD TO ARRAY (FREE FISHING)
        static void AddToArray(int[] thisLevelZoneFish, int i, int currentFishID)
        {
            //thisLevelZoneFish is the array that the randomly selected IDs will be added to
            //i is the current iteration of the for loop that AddToArray was called within
            //currentFishID is a randomly selected fish ID

            thisLevelZoneFish[i] = currentFishID; //the current element in the array becomes the value of currentFishID
        }

        //REVEAL FISH (FREE FISHING)
        //prints which fish is in each zone
        //activated with Show Fish powerup
        private static void RevealFish(int numberOfZones, int[] thisLevelZoneFish)
        {
            //numberOfZones is the number of zones in the location in which the round is taking place
            //thisLevelZoneFish is the array that holds the ID of the fish in the zones
            //locationMenuOption is the value of the location in which the round is taking place

            string zoneSpecies = ""; //will hold the species of the current fish

            //database connection
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=""C:\Documents\NewFunkyFishingDatabase.accdb"";Jet OLEDB:Database Password=1");
            connection.Open();

            for (int i = 0; i < numberOfZones; i++) //for every zone in the location
            {
                //database command
                OleDbCommand getSpecies = new OleDbCommand();
                getSpecies.Connection = connection;
                getSpecies.CommandText = "SELECT * FROM FishTable WHERE ID = " + (thisLevelZoneFish[i]); //takes the current element in the array and finds the fish with a matching ID in FishTable
                OleDbDataReader reader = getSpecies.ExecuteReader();

                while (reader.Read())
                {
                    zoneSpecies = reader["Species"].ToString();
                    Console.WriteLine("Zone " + (i + 1) + " contains: " + zoneSpecies); //prints the zones and the species contained within them (arrays start at 0)
                }
            }
            Console.WriteLine();
        }

        //GENERATE ARROW SEQUENCE (FREE FISHING + SPEED FISHING)
        //creates the sequence that the user must enter correctly in order to catch a fish
        private static string GenerateArrowSequence(int fishRarity, int levelDifficulty)
        {
            //fishRarity is the rarity value of the fish that was randomly put in the zone that the user chose
            //levelDifficulty is the difficulty value of the location in which the round is taking place

            Random RandomNumber = new Random(); //random number

            string arrowSequence = ""; //will contain the sequence

            int numberOfCharacters = fishRarity * levelDifficulty; //length of the sequence (based on rarity and difficulty)


            for (int i = 1; i <= numberOfCharacters; i++) //until the sequence is the required length
            {
                int choosingCharacter = RandomNumber.Next(1, 5); //chooses andom number from 1 to 4

                //adds a character to the sequence based on the random value of choosingCharacter
                if (choosingCharacter == 1)
                {
                    arrowSequence += 'w';
                }
                if (choosingCharacter == 2)
                {
                    arrowSequence += 'a';
                }
                if (choosingCharacter == 3)
                {
                    arrowSequence += 's';
                }
                if (choosingCharacter == 4)
                {
                    arrowSequence += 'd';
                }

            }
            return arrowSequence;
        }

        //VALIDATE ARROW SEQUENCE (FREE FISHING + SPEED FISHING)
        //checks the sequence that the user typed in against the one generated by the program
        private static bool ValidateArrowSequence(string generatedArrowSequence, string userArrowSequence)
        {
            //generatedArrowSequence is the sequence generated by the program
            //userArrowSequence is the sequence that the user typed in

            bool correct = true;

            if (userArrowSequence.Length != generatedArrowSequence.Length) //if the user's sequence is not the same length as the program's sequence...
            {
                correct = false; //...it is not correct
            }
            else
            {
                for (int i = 0; i < generatedArrowSequence.Length; i++) //iterate for the full length of the sequence
                {
                    if (userArrowSequence[i] != generatedArrowSequence[i]) //if the current character of the user's sequence does not match the current character of the program's sequence...
                    {
                        correct = false; //...it is not correct
                    }
                }
            }


            return correct;
        }

        //LOG IN
        //shows at very beginning of program
        //allows the user to create an account in order to save their data
        private static string LogIn()
        {
            DisplayTitle(); //decorative

            Console.WriteLine("What would you like to do?");
            Console.WriteLine("1) Log in with existing user\n2) Create new user");
            Console.WriteLine();

            int choice = Convert.ToInt32(Console.ReadLine());

            string username = "";
            string password = "";

            //database connection
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=""C:\Documents\NewFunkyFishingDatabase.accdb"";Jet OLEDB:Database Password=1");
            connection.Open();
            Console.WriteLine();

            if (choice != 9)
            {
                if (choice == 2) //create new user
                {
                    Console.WriteLine("Enter your username:");
                    username = Console.ReadLine();
                    Console.WriteLine("Enter your password:");
                    password = Console.ReadLine();

                    string dateAndTime = Convert.ToString(DateTime.Now); //holds the current date and time in a string

                    //database command
                    OleDbCommand createNewUser = new OleDbCommand();
                    createNewUser.Connection = connection;
                    createNewUser.CommandText = "INSERT INTO Users ([Username], [Password], [Money], [LevelsUnlocked], [Status], [DateCreated]) VALUES ('" + username + "','" + password + "', '0', '1', 'Novice', '" + dateAndTime + "')"; //inserts a new record into the database with the inputted username and password, and all the default values
                    createNewUser.ExecuteNonQuery();

                    //database command
                    OleDbCommand addUserToFishCount = new OleDbCommand();
                    addUserToFishCount.Connection = connection;
                    addUserToFishCount.CommandText = "ALTER TABLE [FishCount] ADD " + username + " string"; //adds new field into the FishCount table that is named the new username
                    addUserToFishCount.ExecuteNonQuery();

                    Console.WriteLine("\nUser added!");
                }
                Console.WriteLine("\nPlease log in");
                Console.WriteLine("\nEnter your username:");
                username = Console.ReadLine();
                Console.WriteLine("Enter your password:");
                password = Console.ReadLine();

                OleDbCommand logIn = new OleDbCommand();
                logIn.Connection = connection;
                logIn.CommandText = "SELECT * FROM Users WHERE [Username] = '" + username + "' AND [Password] = '" + password + "'"; //selects data from record that matches the details that the user entered

                OleDbDataReader reader = logIn.ExecuteReader();
                while (reader.Read())
                {
                    username = reader["Username"].ToString();
                }
            }
            else
            {
                return "";
            }
            //decorative
            Console.WriteLine("       .\r\n      \":\"\r\n    ___:____     |\"\\/\"|\r\n  ,'        `.    \\  /\r\n  |  O        \\___/  |\r\n~^~^~^~^~^~^~^~^~^~^~^~^~");

            Console.WriteLine("\nYou are now logged in. Have fun!");

            return username;
        }

        //VIEW RECORDS
        private static void RecordBook(string user)
        {
            //user is the logged-in user's name

            //fish records variables
            string recordSpecies = "";
            string recordUser = "";
            double recordWeight = 0;
            string recordDate = "";
            //speed fishing records variables
            string speedFishingRecordUser = "";
            string speedFishingRecordLocation = "";
            int speedFishingRecordPoints = 0;
            string speedFishingRecordDate = "";
            //statistics variables
            string dateCreated = "";

            Console.WriteLine("Welcome! This is the record book. Which records would you like to see?");
            Console.WriteLine("1) Fish Records\n2) Speed Fishing Records\n3) Your Statistics\n9) Exit");
            int recordType = Convert.ToInt32(Console.ReadLine()); //user inputs which records they want to view

            //database connection
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=""C:\Documents\NewFunkyFishingDatabase.accdb"";Jet OLEDB:Database Password=1");
            connection.Open();
            Console.WriteLine();

            switch (recordType)
            {
                case 1: //fish records
                    Console.WriteLine("Which location's records would you like to view?");
                    Console.WriteLine("1) Pond\n2) Beach\n3) River\n4) Reef\n5) Ice\n6) Ocean\n7) Moon");
                    int recordSet = Convert.ToInt32(Console.ReadLine()); //user chooses which fish they want to see records for
                    Console.WriteLine();

                    //database command
                    OleDbCommand viewRecords = new OleDbCommand();
                    viewRecords.Connection = connection;
                    viewRecords.CommandText = "SELECT * FROM Records WHERE LocationID = " + (recordSet + 1); //selects the records for the fish in the location chosen by the user

                    OleDbDataReader reader = viewRecords.ExecuteReader(); //executes command
                    while (reader.Read())
                    {
                        recordSpecies = reader["FishID"].ToString();
                        recordUser = reader["UserID"].ToString();
                        recordWeight = Convert.ToDouble(reader["Weight"].ToString());
                        recordDate = reader["Date/Time"].ToString();

                        if (recordUser == "") //if there is no record yet in the table for the current fish
                        {
                            Console.WriteLine("???: This fish has not yet been caught. Try and be the first to set a record!");
                        }
                        else
                        {
                            Console.WriteLine(recordSpecies.ToUpper() + ": Record set by " + recordUser + ", on " + recordDate + ", with a weight of " + recordWeight + "kg");
                        }
                    }
                    break;
                case 2: //speed fishing

                    //database command
                    OleDbCommand viewSpeedFishingRecords = new OleDbCommand();
                    viewSpeedFishingRecords.Connection = connection;
                    viewSpeedFishingRecords.CommandText = "SELECT * FROM SpeedFishingRecords"; //selects all the speed fishing records

                    OleDbDataReader reader1 = viewSpeedFishingRecords.ExecuteReader();
                    while (reader1.Read())
                    {
                        speedFishingRecordUser = reader1["UserID"].ToString();
                        speedFishingRecordLocation = reader1["LocationID"].ToString();
                        speedFishingRecordPoints = Convert.ToInt32(reader1["Points"].ToString());
                        speedFishingRecordDate = reader1["DateTime"].ToString();

                        if (speedFishingRecordUser == "") //if no record has been set for the current location
                        {
                            Console.WriteLine(speedFishingRecordLocation.ToUpper() + ": There is currently no record for this location. Be the first to set one!");
                        }
                        else
                        {
                            Console.WriteLine(speedFishingRecordLocation.ToUpper() + ": Record held by " + speedFishingRecordUser + " with a score of " + speedFishingRecordPoints + " points, set on " + speedFishingRecordDate);
                        }
                    }
                    break;
                case 3: //statistics

                    //database command
                    OleDbCommand userDetails = new OleDbCommand();
                    userDetails.Connection = connection;
                    userDetails.CommandText = "SELECT * FROM Users WHERE Username = '" + user + "'"; //selects all the information from the record that contains the user's name

                    OleDbDataReader reader2 = userDetails.ExecuteReader();
                    while (reader2.Read())
                    {
                        dateCreated = reader2["DateCreated"].ToString();
                    }

                    Console.WriteLine("Here are the statistics for " + user);
                    Console.WriteLine();

                    int fishCount = GetFishCount(user); //finds the total number of fish caught
                    string status = GetStatus(user, fishCount); //finds the status of the user
                    double money = GetMoney(user); //finds the money that the user possesses

                    Console.WriteLine("Playing since: " + dateCreated);
                    Console.WriteLine("Status: " + status);
                    Console.WriteLine("Total fish caught: " + fishCount);
                    Console.WriteLine("Money: £" + money);

                    break;
                case 9: //exit
                    Console.WriteLine("Thank you!");
                    break;
                default:
                    Console.WriteLine("Invalid entry");
                    Console.WriteLine();
                    RecordBook(user);
                    break;
            }

            Console.WriteLine();
            Console.WriteLine("Press enter to return to the Main Menu");
            Console.ReadLine();
        }

        //GET FISH COUNT
        //finds how many fish a user has caught by counting their records in the FishCount table
        private static int GetFishCount(string user)
        {
            //user is the name of the logged-in user

            int fishCount = 0; //holds how many fish have been caught

            if (user != "AllLevelsUnlocked")
            {
                //database connection
                OleDbConnection connection = new OleDbConnection();
                connection.ConnectionString = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=""C:\Documents\NewFunkyFishingDatabase.accdb"";Jet OLEDB:Database Password=1");
                connection.Open();

                //database command
                OleDbCommand getFishCount = new OleDbCommand();
                getFishCount.Connection = connection;
                getFishCount.CommandText = "SELECT COUNT([" + user + "]) FROM [FishCount]"; //counts and returns the total number of fish listed in the user's field
                getFishCount.ExecuteNonQuery();
                fishCount = Convert.ToInt32(getFishCount.ExecuteScalar());
            }
            else
            {
                fishCount = 1000000000;
            }




            return fishCount;
        }

        //GET STATUS
        //used to find the status of the logged-in user, based on fishCount
        //determines how many levels the user has unlocked
        private static string GetStatus(string user, int fishCount)
        {
            //user is the name of the logged-in user
            //fishCount is the total number of fish the user has caught (uses result from GetFishCount() )

            string status = "Novice"; //all users begin with Novice status

            int levelsUnlocked = 1; //all users begin with 1 level unlocked

            //database connection
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=""C:\Documents\NewFunkyFishingDatabase.accdb"";Jet OLEDB:Database Password=1");
            connection.Open();

            //changes status and levelsUnlocked based on how many fish have been caught
            if (fishCount >= 50 && fishCount < 100)
            {
                status = "Amateur";
                levelsUnlocked = 2;
            }
            else if (fishCount >= 100 && fishCount < 200)
            {
                status = "Intermediate";
                levelsUnlocked = 3;
            }
            else if (fishCount >= 200 && fishCount < 500)
            {
                status = "Professional";
                levelsUnlocked = 4;
            }
            else if (fishCount >= 500 && fishCount < 1000)
            {
                status = "Expert";
                levelsUnlocked = 5;
            }
            else if (fishCount >= 1000 && fishCount < 10000)
            {
                status = "Master";
                levelsUnlocked = 6;
            }
            else if (fishCount >= 10000 && fishCount < 1000000)
            {
                status = "World Champion";
                levelsUnlocked = 7;
            }
            else if (fishCount >= 1000000)
            {
                status = "Fishing Legend";
            }

            //database command
            OleDbCommand updateStatus = new OleDbCommand();
            updateStatus.Connection = connection;
            updateStatus.CommandText = "UPDATE [Users] SET [Status] = '" + status + "', [LevelsUnlocked] = " + levelsUnlocked + " WHERE [Username] = '" + user + "'"; //upadates the record that contains the user's name with the new status and levelsUnlocked values
            updateStatus.ExecuteNonQuery(); //executes command
            return status;
        }
        //GET MONEY
        //retrieves the amount of money owned by the logged-in user from the database
        private static double GetMoney(string user)
        {
            //user is the currently logged-in user's name

            double money = 0;

            //database connection
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=""C:\Documents\NewFunkyFishingDatabase.accdb"";Jet OLEDB:Database Password=1");
            connection.Open();
            Console.WriteLine();

            //database command
            OleDbCommand getMoney = new OleDbCommand();
            getMoney.Connection = connection;
            getMoney.CommandText = "SELECT * FROM [Users] WHERE [Username] = '" + user + "'"; //selects the value from the money field in the record that contains the user's name
            OleDbDataReader reader = getMoney.ExecuteReader();
            while (reader.Read())
            {
                money = Convert.ToDouble(reader["Money"].ToString());
            }
            return money;
        }

        //UPDATE MONEY
        //upadates the amount of money for the logged-in user (keeps track of earnings from fish caught and money spent on Show Fish)
        private static double UpdateMoney(double money, string user)
        {
            //money is the total amount of money owned by the user that will be added to the database
            //user is the currently logged-in user's name

            //database connection
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=""C:\Documents\NewFunkyFishingDatabase.accdb"";Jet OLEDB:Database Password=1");
            connection.Open();

            //database command
            OleDbCommand updateMoney = new OleDbCommand();
            updateMoney.Connection = connection;
            updateMoney.CommandText = "UPDATE Users SET [Money] = " + money + " WHERE [Username] = '" + user + "'"; //updates the money field in the record that contains the current user's username
            updateMoney.ExecuteNonQuery();

            return money;
        }

        //SPEED FISHING ENQUEUE (SPEED FISHING)
        //used to add fish to the queue that will be used for Speed Fishing
        private static Queue SpeedFishingEnqueue(Queue SpeedFishingQueue, int locationMenuOption)
        {
            //locationMenuOption is the value of the location in which the round of Speed Fishing is taking place

            int numberOfFish = locationMenuOption * 8; //how many fish will be in the queue (dependent on location - harder locations have more fish)

            string fish = "";

            Random random = new Random(); //random number
            int randomFish = 0;

            //database connection
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=""C:\Documents\NewFunkyFishingDatabase.accdb"";Jet OLEDB:Database Password=1");
            connection.Open();

            for (int i = 0; i <= numberOfFish; i++) //until the queue has reached its required length
            {
                randomFish = random.Next(1, 7); //picks random number between 1 and 6 (6 types of fish in a location)

                //database command
                OleDbCommand getFish = new OleDbCommand();
                getFish.Connection = connection;
                getFish.CommandText = "SELECT * FROM FishTable WHERE [ID] = " + (randomFish + ((locationMenuOption - 1) * 6)); //calculation required to find the corret fish for the selected location
                OleDbDataReader reader = getFish.ExecuteReader();
                while (reader.Read())
                {
                    fish = reader["Species"].ToString();

                }
                SpeedFishingQueue.Enqueue(fish); //adds the randomly selected fish to the queue
            }

            return SpeedFishingQueue;
        }

        //CALCULATE POINTS (SPEED FISHING)
        //calculates points based on the user's actions in Speed Fishing
        private static int CalculatePoints(int locationMenuOption, int queueLength, int fishCount, int rarityPoints, double seconds)
        {
            //rarityPoints are the points calculated from the number of rare fish caught in a round of speed fishing
            //fishCount is the number of fish caught in a round of speed fishing
            //locationMenuOption is the value of the location in which the round of speed fishing has taken place
            //seconds is the number of seconds taken to complete the round of speed fishing
            //queueLength is the length of the queue of fish used in the round of speed fishing

            //timePointsLimit determines the maximum time that points can be accquired from the time taken to complete the round

            int points = 0; //point total
            int timePoints = 0; //points calculated based on the user's time

            points = (rarityPoints * fishCount);

            int timePointsLimit = (queueLength + 1) * (locationMenuOption + 1); //dependent on the features of the location (locations with longer queues have a higher maximum time)

            if (seconds < timePointsLimit) //if the user completed the level in less than the maximum time...
            {
                timePoints = (points * locationMenuOption) + (timePointsLimit - Convert.ToInt32(seconds)); //...calculate timePoints (based on features of the location and the amount of time taken to complete the level)
                points += timePoints; //add timePoints to the point total
            }

            return points;
        }

        //DISPLAY TITLE
        private static void DisplayTitle() //decorative
        {
            Console.WriteLine("\r\n    ______            __            _______      __    _            \r\n   / ____/_  ______  / /____  __   / ____(_)____/ /_  (_)___  ____ _\r\n  / /_  / / / / __ \\/ //_/ / / /  / /_  / / ___/ __ \\/ / __ \\/ __ `/\r\n / __/ / /_/ / / / / ,< / /_/ /  / __/ / (__  ) / / / / / / / /_/ / \r\n/_/    \\__,_/_/ /_/_/|_|\\__, /  /_/   /_/____/_/ /_/_/_/ /_/\\__, /  \r\n                       /____/                              /____/   \r\n");
        }

    }
}